
%%
num=8;
th=0.1;


%%
%main_RADF('bear',num,th,1,9)
%main_RADF('motocross-jump',num,th,1,9)
%main_RADF('blackswan',num,th,1,9)
main_RADF('dance-jump',num,th,1,9)
%main_RADF('dance-twirl',num,th,1,9)
main_RADF('bmx-bumps',num,th,1,9)
%main_RADF('bmx-trees',num,th,1,9)
%main_RADF('boat',num,th,1,9)
main_RADF('breakdance',num,th,1,9)
%main_RADF('breakdance-flare',num,th,1,9)
%main_RADF('bus',num,th,1,9)
%main_RADF('camel',num,th,1,9)
%main_RADF('car-roundabout',num,th,1,9)
%main_RADF('car-shadow',num,th,1,9)
%main_RADF('car-turn',num,th,1,9)
%main_RADF('cows',num,th,1,9)
%main_RADF('dog',num,th,1,9)
main_RADF('dog-agility',num,th,1,9)


%{
main_RADF('drift-chicane',num,th,1,9)
main_RADF('drift-straight',num,th,1,9)
main_RADF('drift-turn',num,th,1,9)
main_RADF('elephant',num,th,1,9)
main_RADF('flamingo',num,th,1,9)
main_RADF('goat',num,th,1,9)
main_RADF('hike',num,th,1,9)
main_RADF('hockey',num,th,1,9)
main_RADF('horsejump-high',num,th,1,9) 
main_RADF('horsejump-low',num,th,1,9)
main_RADF('kite-surf',num,th,1,9)
main_RADF('kite-walk',num,th,1,9)
main_RADF('libby',num,th,1,9)
main_RADF('lucia',num,th,1,9)
main_RADF('mallard-fly',num,th,1,9)
main_RADF('mallard-water',num,th,1,9)
main_RADF('motocross-bumps',num,th,1,9)
main_RADF('motorbike',num,th,1,9)
main_RADF('paragliding',num,th,1,9)
main_RADF('paragliding-launch',num,th,1,9)
main_RADF('parkour',num,th,1,9)
main_RADF('rhino',num,th,1,9)
main_RADF('rollerblade',num,th,1,9)
main_RADF('scooter-black',num,th,1,9)
main_RADF('scooter-gray',num,th,1,9)
main_RADF('soapbox',num,th,1,9)
main_RADF('soccerball',num,th,1,9)
main_RADF('stroller',num,th,1,9)
main_RADF('surf',num,th,1,9)
main_RADF('swing',num,th,1,9)
main_RADF('tennis',num,th,1,9)
main_RADF('train',num,th,1,9)


%% MCL
main_RADF('MCL\Ball',num,th,1,9);
main_RADF('MCL\Campus',num,th,1,9);
main_RADF('MCL\Car',num,th,1,9)
main_RADF('MCL\Court',num,th,1,9)
main_RADF('MCL\Crowd',num,th,1,9)
main_RADF('MCL\Hall2',num,th,1,9)
main_RADF('MCL\Road',num,th,1,9)
main_RADF('MCL\Square',num,th,1,9)
main_RADF('MCL\Stair',num,th,1,9)



%% SegTrack
main_RADF('SegTrack\bird_of_paradise',num,th,1,9)
main_RADF('SegTrack\birdfall',num,th,1,9)
main_RADF('SegTrack\bmx',num,th,1,9)
main_RADF('SegTrack\cheetah',num,th,1,9)
main_RADF('SegTrack\drift',num,th,1,9)
main_RADF('SegTrack\frog',num,th,1,9)
main_RADF('SegTrack\girl',num,th,1,9)
main_RADF('SegTrack\hummingbird',num,th,1,9)
main_RADF('SegTrack\monkey',num,th,1,9)
main_RADF('SegTrack\monkeydog',num,th,1,9)
main_RADF('SegTrack\parachute',num,th,1,9)
main_RADF('SegTrack\soldier',num,th,1,9)
main_RADF('SegTrack\worm',num,th,1,9)


%% FBMS
main_RADF('FBMS\camel01\Imgs',num,th,1,9);
main_RADF('FBMS\cars1\Imgs',num,th,1,9);%
main_RADF('FBMS\cars4\Imgs',num,th,1,9)%
main_RADF('FBMS\cars5\Imgs',num,th,1,9)%
main_RADF('FBMS\cars10\Imgs',num,th,1,9)%
main_RADF('FBMS\cats01\Imgs',num,th,1,9)%
main_RADF('FBMS\cats03\Imgs',num,th,1,9)%
main_RADF('FBMS\cats06\Imgs',num,th,1,9)%
main_RADF('FBMS\dogs01\Imgs',num,th,1,9)%
main_RADF('FBMS\dogs02\Imgs',num,th,1,9);%
main_RADF('FBMS\farm01\Imgs',num,th,1,9);%
main_RADF('FBMS\giraffes01\Imgs',num,th,1,9)%
main_RADF('FBMS\goats01\Imgs',num,th,1,9)%
main_RADF('FBMS\horses02\Imgs',num,th,1,9)%

main_RADF('FBMS\horses04\Imgs',num,th,1,9)%
main_RADF('FBMS\horses05\Imgs',num,th,1,9)%
main_RADF('FBMS\lion01\Imgs',num,th,1,9)%
main_RADF('FBMS\marple2\Imgs',num,th,1,9)%
main_RADF('FBMS\marple4\Imgs',num,th,1,9);%
main_RADF('FBMS\marple6\Imgs',num,th,1,9);%
main_RADF('FBMS\marple7\Imgs',num,th,1,9)%
main_RADF('FBMS\marple9\Imgs',num,th,1,9)%
main_RADF('FBMS\marple12\Imgs',num,th,1,9)%
main_RADF('FBMS\people1\Imgs',num,th,1,9)%
main_RADF('FBMS\people2\Imgs',num,th,1,9)%
main_RADF('FBMS\people03\Imgs',num,th,1,9)%
main_RADF('FBMS\rabbits02\Imgs',num,th,1,9)%
main_RADF('FBMS\rabbits03\Imgs',num,th,1,9);%
main_RADF('FBMS\rabbits04\Imgs',num,th,1,9);%
main_RADF('FBMS\tennis\Imgs',num,th,1,9)%

%% UVSD
main_RADF('UVSD\Climb',num,th,1,9);%
main_RADF('UVSD\Couple',num,th,1,9);%
main_RADF('UVSD\Deer',num,th,1,9)%
main_RADF('UVSD\DH',num,th,1,9)%
main_RADF('UVSD\Diving',num,th,1,9)%
main_RADF('UVSD\Fencing',num,th,1,9)%
main_RADF('UVSD\HighJump',num,th,1,9)%
main_RADF('UVSD\HorseRiding3',num,th,1,9)%
main_RADF('UVSD\JavelinThrow',num,th,1,9)%
main_RADF('UVSD\Jogging',num,th,1,9);%
main_RADF('UVSD\MotorRolling',num,th,1,9);%
main_RADF('UVSD\MountainBike',num,th,1,9)%
main_RADF('UVSD\PommelHorse',num,th,1,9)%
main_RADF('UVSD\Singer',num,th,1,9)%
main_RADF('UVSD\skating',num,th,1,9)%
main_RADF('UVSD\Skiing',num,th,1,9)%
main_RADF('UVSD\Waterski',num,th,1,9)%
main_RADF('UVSD\yunakim_long2',num,th,1,9)
%}