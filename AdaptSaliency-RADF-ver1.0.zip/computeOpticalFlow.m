function computeOpticalFlow(ImgIndex,para,mode)
%fprintf('Begin Optical Flow computation...\n');
% set optical flow parameters (see Coarse2FineTwoFrames.m for the definition of the parameters)
alpha = 0.012;%0.012
ratio = 0.75;%0.75
minWidth = 20;%20
nOuterFPIterations = 7;%7
nInnerFPIterations = 1;%1
nSORIterations = 30;%30
OpticalFlowPara = [alpha,ratio,minWidth,nOuterFPIterations,nInnerFPIterations,nSORIterations];
sigma_s = 100;sigma_r = 0.2;%RF Smoothing Parameter

path = para.path;
Files = para.Files;
% count = 0;
% LengthFiles = para.LengthFiles-1;
% Span = floor(LengthFiles/2)+3;
   ImageName1 = Files(ImgIndex).name;
   ImagePath1 = [path ImageName1];
   I1 = imread(ImagePath1);
   ImageName2 = Files(ImgIndex+1).name;
   ImagePath2 = [path ImageName2];
   I2 = imread(ImagePath2);
   tic
   I1 = imresize(I1,[300,300]);
   I2 = imresize(I2,[300,300]);
   ISmoothed1 = RF(im2double(I1), sigma_s, sigma_r);%RF smoothing 
   ISmoothed2 = RF(im2double(I2), sigma_s, sigma_r);
  tic
   [vx,vy,warpI2] = Coarse2FineTwoFrames(ISmoothed1,ISmoothed2,OpticalFlowPara);
   %%%% ===============================================================
   OpticalFlow(:,:,1) = vx;
   OpticalFlow(:,:,2) = vy;
   OpticalFlowIm = flowToColor(OpticalFlow);
   OpticalFlowIm = imresize(OpticalFlowIm,[400,400]);
   

   resultName = [para.OpticalFlowResultPath ImageName1(1:end-4) '.jpg'];
   imwrite(OpticalFlowIm,resultName);
   
   %%%% ===============================================================
toc
   CurrentOpticalFlow.vx = vx;
   CurrentOpticalFlow.vy = vy;
   toc
   %save([para.OpticalFlowPath ImageName1(1:end-4) '.mat'],'-struct','CurrentOpticalFlow');
   
   fprintf('frame %d done!\n', ImgIndex-2);

