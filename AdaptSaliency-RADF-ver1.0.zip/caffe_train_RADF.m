
function caffe_train_RADF(max_iter,snapshot, mode,  num,gt_threshold,base1,base2 , iter)

%% дsolver.prototxt

mode_for_matlab_path = mode;
% if containing '\'
for i = 1:length(mode)
    if(strcmp(mode(i),'\'))
        mode(i) = '/';
    end
end

 
 %base_lr = base;
 base_lr_word = sprintf(('base_lr: %de-%d'),base1,base2); 
 
 %max_iter = 8;
 max_iter_word = sprintf(('max_iter: %d'),max_iter*num);%10 
 
 %snapshot = 8;
 snapshot_word = sprintf(('snapshot: %d'),snapshot*num);  
 stepsize_word = sprintf(('stepsize: %d'),ceil(snapshot*num)); 


 snapshot_prefix_word = ['snapshot_prefix: "./train/' mode '/' num2str(iter) '/snapshotRADF_' num2str(base1) num2str(base2) '"'];

 train_net = ['train_net:"./fit-RADF/' mode '/train_val_RADF_iter_' num2str(iter) '.prototxt" '];
 
 %{'base_lr: 1e-9 '}, ...%
 
 text = [ base_lr_word, ...
{'lr_policy: "step"'} , ...
{'gamma: 0.1'} , ...
{'iter_size: 1'} , ...
stepsize_word , ...
max_iter_word , ...  
{'momentum: 0.95'} , ... 
{'weight_decay: 0.0005'} , ...
snapshot_word , ...
snapshot_prefix_word , ...
train_net ];



s=strcat('mkdir ',[' .\fit-RADF\' mode_for_matlab_path '\']);system(s);
id1 = fopen(['.\fit-RADF\' mode_for_matlab_path '\solver_RADF_iter_' num2str(iter) '.prototxt'],'w+');
for i = 1:length(text)    
    fprintf(id1,'%s\r\n',text{i});
end
fclose(id1);


%% ���뵽ָ����
network_text{1} = ['root_folder: "./train/' mode '/' num2str(iter) '/"'];
network_text{2} = ['source: "./train/' mode '/' num2str(iter) '/trainName.txt"'];

network_text{3} = ['# mirror : true'];

network_text{4} = ['#new_height : 300'];
network_text{5} = ['#new_width : 300'];

%ֻ��
id21 = fopen(['train_val_RADF_Euclidean.prototxt'],'r');
%re-write every time
id22 = fopen(['.\fit-RADF\' mode_for_matlab_path '\train_val_RADF_iter_' num2str(iter) '.prototxt'],'w+');

num_line = 1;
tline = fgetl(id21);
while ischar(tline)
    if(num_line ~= 13 && num_line ~= 16 && num_line ~= 18 && num_line ~= 19)% 13 16// 16 19
        fprintf(id22,'%s\r\n',tline);
    elseif(num_line == 13)
            fprintf(id22,'%s\r\n',network_text{1});
    elseif(num_line == 16)
       fprintf(id22,'%s\r\n',network_text{2});
    elseif(num_line == 18)
        fprintf(id22,'%s\r\n',network_text{4});
    elseif(num_line == 19)
        fprintf(id22,'%s\r\n',network_text{5});
    end    

    tline = fgetl(id21);
    num_line = num_line + 1;
end
fclose(id21);
fclose(id22);

%% train

caffe.reset_all  
caffe.set_mode_gpu();%����cpu��gpuģʽ


caffe_model = 'RADF_iter_10000.caffemodel'; %΢��ʹ��
solver=caffe.Solver(['.\fit-RADF\' mode_for_matlab_path '\solver_RADF_iter_' num2str(iter) '.prototxt']);%Э���ļ�����·��
solver.net.copy_from(caffe_model);  %΢��ʹ��




%% step-wise
iter_ = solver.iter();%get iteration number
loss = [];
loss_temp = 0;
loss_pre = 0;
while iter_<max_iter*num  
    solver.step(1);
    iter_ = solver.iter();%get iteration number
    
    fprintf('-----------iteration = %f -----------\n', iter_);
    
    loss1=solver.net.blobs('loss-dsn1').get_data();%ȡѵ������loss  
    fprintf('loss1 = %f \n', loss1);
    loss2=solver.net.blobs('loss-dsn2').get_data();%ȡѵ������loss  
    fprintf('loss2 = %f \n', loss2);
    loss3=solver.net.blobs('loss-dsn3').get_data();%ȡѵ������loss 
    fprintf('loss3 = %f \n', loss3);
    loss4=solver.net.blobs('loss-dsn4').get_data();%ȡѵ������loss  
    fprintf('loss4 = %f \n', loss4);
    loss5=solver.net.blobs('loss-dsn5').get_data();%ȡѵ������loss  
    fprintf('loss5 = %f \n', loss5);
    loss6=solver.net.blobs('loss-dsn6').get_data();%ȡѵ������loss  
    fprintf('loss6 = %f \n', loss6);
    loss_fuse=solver.net.blobs('loss-fuse').get_data();%ȡѵ������loss
    fprintf('loss_fuse = %f \n', loss_fuse);
    
    loss2a=solver.net.blobs('loss-dsn2a').get_data();%ȡѵ������loss  
    fprintf('loss2a = %f \n', loss2a);
    loss3a=solver.net.blobs('loss-dsn3a').get_data();%ȡѵ������loss  
    fprintf('loss3a = %f \n', loss3a);
    loss4a=solver.net.blobs('loss-dsn4a').get_data();%ȡѵ������loss 
    fprintf('loss4a = %f \n', loss4a);
    loss5a=solver.net.blobs('loss-dsn5a').get_data();%ȡѵ������loss  
    fprintf('loss5a = %f \n', loss5a);
    loss6a=solver.net.blobs('loss-dsn6a').get_data();%ȡѵ������loss 
    fprintf('loss6a = %f \n', loss6a);
    loss1a=solver.net.blobs('loss-dsn1a').get_data();%ȡѵ������loss  
    fprintf('loss1a = %f \n', loss1a);
    
    
    loss_temp = loss_temp + loss_fuse;
    if( mod(iter_, max_iter) == 0)
        loss = [loss loss_temp]   %output
        
        if(abs(loss_temp - loss_pre) < 50)
            break;
        end
        loss_pre = loss_temp;
        
        
        loss_temp = 0;
    end
end







if(iter_ < max_iter*num)

 %base_lr = base;
 base_lr_word = sprintf(('base_lr: %de-%d'),base1,base2); 
 
 %max_iter = 8;
 max_iter_word = sprintf(('max_iter: %d'),max(max_iter,iter_-max_iter*2));
 
 %snapshot = 8;
 snapshot_word = sprintf(('snapshot: %d'),max(max_iter,iter_-max_iter*2));  
 stepsize_word = sprintf(('stepsize: %d'),max(max_iter,iter_-max_iter*2)); 

 snapshot_prefix_word = ['snapshot_prefix: "./train/' mode '/' num2str(iter) '/snapshotRADF_' num2str(base1) num2str(base2) '"'];
 train_net = ['train_net:"./fit-RADF/' mode '/train_val_RADF_iter_' num2str(iter) '.prototxt" '];
 
 %{'base_lr: 1e-9 '}, ...%
 
 text = [ base_lr_word, ...
{'lr_policy: "step"'} , ...
{'gamma: 0.1'} , ...
{'iter_size: 1'} , ...
stepsize_word , ...
max_iter_word , ...  
{'momentum: 0.95'} , ... %
{'weight_decay: 0.0005'} , ...%0.0005
snapshot_word , ...
snapshot_prefix_word , ...
train_net ];


s=strcat('mkdir ',[' .\fit-RADF\' mode_for_matlab_path '\']);system(s);
id1 = fopen(['.\fit-RADF\' mode_for_matlab_path '\solver_RADF_iter_' num2str(iter) '.prototxt'],'w+');
for i = 1:length(text)    
    fprintf(id1,'%s\r\n',text{i});
end
fclose(id1);


caffe.reset_all  
caffe.set_mode_gpu();%����cpu��gpuģʽ
caffe_model = 'RADF_iter_10000.caffemodel'; %΢��ʹ��
solver=caffe.Solver(['.\fit-RADF\' mode_for_matlab_path '\solver_RADF_iter_' num2str(iter) '.prototxt']); %Э���ļ�����·��
solver.net.copy_from(caffe_model);  %΢��ʹ��
solver.solve();
end
%}

end