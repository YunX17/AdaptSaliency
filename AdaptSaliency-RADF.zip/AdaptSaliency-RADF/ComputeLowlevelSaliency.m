function ComputeLowlevelSaliency(computeCol,mode,ImgIndex,para)
LowlevelSaliencyPath = para.LowlevelSaliencyPath;
Files = para.Files;
       ImageName = Files(ImgIndex).name;   
       if computeCol == 1

                MotionSaliencyMap = single(imread([para.MotionSaliencyPath ImageName(1:end-4) '.jpg']));
                MotionSaliencyMap = MotionSaliencyMap(:,:,1) ./ 255;
                MotionSaliencyMap = imresize(MotionSaliencyMap,[300 300]);
                
                



                ColorSaliencyMap = single(imread([para.ColorSaliencyPath ImageName(1:end-4) '.jpg']));
                ColorSaliencyMap = ColorSaliencyMap(:,:,1) ./ 255;
                ColorSaliencyMap = imresize(ColorSaliencyMap,[300 300]);
                 
                
                SMSR = im2bw(imresize(MotionSaliencyMap,[150,150]), graythresh(MotionSaliencyMap));
                SCSR = im2bw(imresize(ColorSaliencyMap,[150,150]), graythresh(ColorSaliencyMap));  
                
                

                average = [ImgIndex  mean(mean(abs(SMSR - SCSR)))];
                %}
               
                

                SMSR = imresize(MotionSaliencyMap,[150,150]);
                SCSR = imresize(ColorSaliencyMap,[150,150]);
                SMSR(SMSR<=0.1) = 0;
                SCSR(SCSR<=0.1) = 0;
                value = abs(normalizeMatrix(SMSR)-normalizeMatrix(SCSR))./(normalizeMatrix(SMSR) + normalizeMatrix(SCSR) + 1e-10);
                
                denominator = normalizeMatrix(SMSR) + normalizeMatrix(SCSR);
                num = numel(find(denominator>=0.1));
                average1 = [ImgIndex  sum(sum(value))/num]; 
                save([ para.AveragePath ImageName(1:end-4) 'average1.mat'],'average1');
                %}


                LowlevelSaliency = ColorSaliencyMap.*MotionSaliencyMap;
                

                LowlevelSaliency = normalizeMatrix(LowlevelSaliency);
                

       else

                MotionSaliencyMap = single(imread([para.MotionSaliencyPath ImageName(1:end-4) '.jpg']));
                MotionSaliencyMap = MotionSaliencyMap(:,:,1) ./ 255;
                MotionSaliencyMap = imresize(MotionSaliencyMap,[300 300]);
                
                SMSR = im2bw(imresize(MotionSaliencyMap,[150,150]), graythresh(MotionSaliencyMap));
                %%%%%%%%%%%%%%%%%%%% ===========
                average = [ImgIndex  mean(mean(SMSR))];
                
                

                
                MotionSaliencyMap(find(MotionSaliencyMap(:)<= 0.5)) = 0;
                LowlevelSaliency = MotionSaliencyMap;

       end
       % �ָ���ԭͼ��С
       temp = imresize(LowlevelSaliency,[para.W para.H]);
       imwrite(temp,[LowlevelSaliencyPath ImageName(1:end-4) '.jpg']);       
       save([ para.AveragePath ImageName(1:end-4) 'average.mat'],'average');          
end