function main_RADF(mode,num,gt_threshold,base1,base2)
    %warning off 
    
    
    Files = [];
    path = ['.\sequence\original\' mode '\'];
    Files1 = dir([path,'*.jpg']);
    if( ~isempty([Files1]) )
        Files = Files1;
    end
    Files2 = dir([path,'*.png']);
    if( ~isempty([Files2]) )
        Files = Files2;
    end
    Files3 = dir([path,'*.bmp']);
    if( ~isempty([Files3]) )
        Files = Files3;
    end
    if( isempty([Files]) )
        fprintf('Empty path!\n');
        return;
    end
    
    
    mode
    para.MotionSaliencyPath=['.\sequence\MotionSaliency\' mode '\'];mkdir(para.MotionSaliencyPath);
    para.AveragePath=['.\sequence\Average\' mode '\'];mkdir(para.AveragePath);
    para.LowlevelSaliencyPath=['.\sequence\LowlevelSaliency\' mode '\'];mkdir(para.LowlevelSaliencyPath);
    
    para.ColorSaliencyPath=['.\sequence\ColorSaliency\' mode '\'];mkdir(para.ColorSaliencyPath);
    para.OpticalFlowResultPath=['.\OpticalFlowResult\' mode '\'];mkdir(para.OpticalFlowResultPath);


        para.Files = Files;
        LengthFiles = size(Files, 1);
        para.LengthFiles = LengthFiles;
        para.path = path;
        ImageName = Files(3).name;
        ImagePath = [path ImageName];
        I = imread(ImagePath);
        W = size(I,1);H = size(I,2);
        para.W = W; para.H = H;
        scale = 2;
        vote = 2;
        smooth = [];
        computeCol = 0;

   
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
                    fprintf('Step 1. Optical Flow Computation...\n');
                    ImgIndex = 1;
                    LengthFiles = para.LengthFiles;
                    tic
                    while(ImgIndex<=LengthFiles-1)
                      parfor i=1:4
                          if(i==1)
                              CImgIndex = ImgIndex;
                              if(CImgIndex<=LengthFiles-1)
                                  computeOpticalFlow(CImgIndex,para,mode);
                              end
                          end
                          if(i==2)
                              CImgIndex = ImgIndex+1;
                              if(CImgIndex<=LengthFiles-1)
                                  computeOpticalFlow(CImgIndex,para,mode);
                              end
                          end
                          if(i==3)
                              CImgIndex = ImgIndex+2;
                              if(CImgIndex<=LengthFiles-1)
                                   computeOpticalFlow(CImgIndex,para,mode);
                              end
                          end
                          if(i==4)
                              CImgIndex = ImgIndex+3;
                              if(CImgIndex<=LengthFiles-1)
                                   computeOpticalFlow(CImgIndex,para,mode);
                              end
                          end
                      end
                       ImgIndex = ImgIndex + 4;
                    end
                    toc
                    fprintf('done!\n');
  %}   

                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   fprintf('Step 2. Begin Motion Saliency Computation...\n');
                    caffe.set_mode_gpu();       %����cpu����gpuģʽ
                    caffe.reset_all();

                    deploy = 'deploy_resnet.prototxt';      %����ģ�ͽṹ
                    caffe_model = 'MotionSaliencyDetector.caffemodel';     %ѵ���õ�ģ��

                    net = caffe.Net(deploy, caffe_model, 'test');     %�����������ֱ���������Խṹ��ѵ���õĲ���ģ�ͣ�test
                    
                    ImageName = Files(3).name;
                    ImagePath = [path ImageName];
                    I_orignal = imread(ImagePath);
                    imageHeight = size(I_orignal,1);imageWidth = size(I_orignal,2);
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                    
          tic
    for k=1:LengthFiles-1
    
    EPSILON = 1e-28;    
    ImageName = Files(k).name;
    
    
    ImagePath = [para.OpticalFlowResultPath ImageName(1:end-4) '.jpg'];
    I_orignal_OP = imread(ImagePath);

    I_orignal_OP = imresize(I_orignal_OP,[500,500]);
    I_orignal_OP = single(I_orignal_OP);
    

    % convert image to BGR and single
         I_orignal_OP = I_orignal_OP(:,:,[3 2 1]);
         I_orignal_OP = permute(I_orignal_OP, [2, 1, 3]); % ת����width��height����
         
         
         net.blobs('data').reshape([500 500 3 1]); % reshape blob 'data'
         net.reshape();
         %input_data must be a cell array
         net.forward({I_orignal_OP});%crop

      
         out1 = net.blobs('sigmoid-dsn2').get_data();
         out2 = net.blobs('sigmoid-dsn3').get_data();
         out3 = net.blobs('sigmoid-dsn4').get_data();
         out4 = net.blobs('sigmoid-dsn5').get_data(); 
         out5 = net.blobs('sigmoid-dsn6').get_data();
         out6 = net.blobs('sigmoid-fuse').get_data();


         res = (out1 + out2 + out6 + out3 + out4 + out5) / 6;
         res=res(end:-1:1,:);%����      
         res=imrotate(res,-90);%��ת
         res = (res - min(res(:)) + EPSILON) / (max(res(:)) - min(res(:)) + EPSILON);
         
         res = imresize(res,[imageHeight imageWidth]);            
         imwrite(res,[para.MotionSaliencyPath ImageName(1:end-4) '.jpg']);
    end
    caffe.reset_all();
%}
    



                        for i=1:LengthFiles-1
                             ImageName = Files(i).name;
                                                         
                             MotionSaliencyMap = single(imread([para.MotionSaliencyPath ImageName(1:end-4) '.jpg']));
                             MotionSaliencyMap = MotionSaliencyMap(:,:,1);
                             
                             MotionSaliencyMap = normalizeMatrix(MotionSaliencyMap);%save results      
                             SMSR = im2bw(imresize(MotionSaliencyMap,[150,150]), graythresh(MotionSaliencyMap)); 
                             persent = sum(sum(SMSR==1))/22500;
                             save([para.AveragePath ImageName(1:end-4) 'persent.mat'],'persent');
                        end
    
                        persent_all = 0;
                        for i=1:LengthFiles-1
                             ImageName = Files(i).name;
                             persent = load([para.AveragePath ImageName(1:end-4) 'persent.mat']);
                             persent = persent.persent;
                             persent_all = persent_all + persent;
                        end
                        mode
                        persent = persent_all/(LengthFiles-1)
                        
                     
                                       

                       if persent < 0.0250
                           computeCol = 0 ;
                       else
                           computeCol = 1 ;
                       end
                       
            toc           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                        
                     
                       if computeCol == 1
                                 fprintf('Step 3. Compute Color Saliency...\n');
                                 tic                                
                                 caffe.set_mode_gpu();       %����cpu����gpuģʽ
                                 caffe.reset_all();

                                 deploy = 'deploy.prototxt';      %����ģ�ͽṹ
                                 caffe_model = 'RADF_iter_10000.caffemodel';     %ѵ���õ�ģ��
                                
                                 net = caffe.Net(deploy, caffe_model, 'test');     %�����������ֱ���������Խṹ��ѵ���õĲ���ģ�ͣ�test
                                        for k=1:LengthFiles-1%������֡

                                            EPSILON = 1e-8;

                                            ImageName = Files(k).name;
                                            ImagePath = [path ImageName];
                                            I_orignal = imread(ImagePath);

                                            % keep the same opeartion with
                                            % C++ code . (exclude AntiAliasing, AntiAliasing may decline precision)
                                            I_orignal = imresize(I_orignal,[400,400],'AntiAliasing',false);
                                            I_orignal = single(I_orignal);

                                            I_orignal = I_orignal(:,:,[3 2 1]);
                                                                                       
                                            
                                            I_orignal(:,:,1) = I_orignal(:,:,1) - single(104.00698793);
                                            I_orignal(:,:,2) = I_orignal(:,:,2) - single(116.66876762);
                                            I_orignal(:,:,3) = I_orignal(:,:,3) - single(122.67891434);
                                            

                                            % convert image to BGR and single
                                                 
                                                 I_orignal = permute(I_orignal, [2, 1, 3]); % ת����width��height����

                                                 
                                                 net.blobs('data').reshape([400 400 3 1]); % reshape blob 'data'
                                                 net.reshape();
                                                 %input_data must be a cell array
                                                 net.forward({I_orignal});

                                                 out1 = net.blobs('sigmoid-dsn1').get_data();
                                                 %out1=out1(end:-1:1,:);%����      
                                                 %out1=imrotate(out1,-90);%��ת

                                                 out2 = net.blobs('sigmoid-dsn2').get_data();
                                                 %out2=out2(end:-1:1,:);%����      
                                                 %out2=imrotate(out2,-90);%��ת

                                                 out3 = net.blobs('sigmoid-dsn3').get_data();
                                                 %out3=out3(end:-1:1,:);%����      
                                                 %out3=imrotate(out3,-90);%��ת

                                                 out4 = net.blobs('sigmoid-dsn4').get_data();
                                                 %out4=out4(end:-1:1,:);%����      
                                                 %out4=imrotate(out4,-90);%��ת

                                                 out5 = net.blobs('sigmoid-dsn5').get_data();
                                                 %out5=out5(end:-1:1,:);%����      
                                                 %out5=imrotate(out5,-90);%��ת

                                                 out6 = net.blobs('sigmoid-dsn6').get_data();
                                                 %out6=out6(end:-1:1,:);%����      
                                                 %out6=imrotate(out6,-90);%��ת

                                                 fuse = net.blobs('sigmoid-fuse').get_data();
                                                 %fuse=fuse(end:-1:1,:);%����      
                                                 %fuse=imrotate(fuse,-90);%��ת

                                                 out2a = net.blobs('sigmoid-dsn2a').get_data();
                                                 %out2a=out2a(end:-1:1,:);%����      
                                                 %out2a=imrotate(out2a,-90);%��ת

                                                 out3a = net.blobs('sigmoid-dsn3a').get_data();
                                                 %out3a=out3a(end:-1:1,:);%����      
                                                 %out3a=imrotate(out3a,-90);%��ת

                                                 out4a = net.blobs('sigmoid-dsn4a').get_data();
                                                 %out4a=out4a(end:-1:1,:);%����      
                                                 %out4a=imrotate(out4a,-90);%��ת

                                                 out5a = net.blobs('sigmoid-dsn5a').get_data();
                                                 %out5a=out5a(end:-1:1,:);%����      
                                                 %out5a=imrotate(out5a,-90);%��ת

                                                 out6a = net.blobs('sigmoid-dsn6a').get_data();
                                                 %out6a=out6a(end:-1:1,:);%����      
                                                 %out6a=imrotate(out6a,-90);%��ת

                                                 out1a = net.blobs('sigmoid-dsn1a').get_data();
                                                 %out1a=out1a(end:-1:1,:);%����      
                                                 %out1a=imrotate(out1a,-90);%��ת

                                                 res = (out1 + out2 + out6 + out3 + out4 + out5 + fuse + out2a + out1a + out3a + out4a + out5a + out6a) / 13;
                                                 res=res(end:-1:1,:);%����      
                                                 res=imrotate(res,-90);%��ת
                                                 res = (res - min(res(:)) + EPSILON) / (max(res(:)) - min(res(:)) + EPSILON);
                                                 
                                                 res = imresize(res,[imageHeight imageWidth]);
                                                 imwrite(res,[para.ColorSaliencyPath ImageName(1:end-4) '.jpg']);            
                                        end
                                  toc
                       end
                       caffe.reset_all();
                     
        %}               
                       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
                                fprintf('Step 4. Compute LowLevel Saliency...\n');
                                ImgIndex = 1;
                                LengthFiles = para.LengthFiles;
                                tic
                                while(ImgIndex<=LengthFiles-1)
                                  for i=1:4
                                      if(i==1)
                                          CImgIndex = ImgIndex;
                                          if(CImgIndex<=LengthFiles-1)
                                              ComputeLowlevelSaliency(computeCol,mode,CImgIndex,para);
                                          end
                                      end
                                      if(i==2)
                                          CImgIndex = ImgIndex+1;
                                          if(CImgIndex<=LengthFiles-1)
                                               ComputeLowlevelSaliency(computeCol,mode,CImgIndex,para);
                                          end
                                      end
                                      if(i==3)
                                          CImgIndex = ImgIndex+2;
                                          if(CImgIndex<=LengthFiles-1)
                                               ComputeLowlevelSaliency(computeCol,mode,CImgIndex,para);
                                          end
                                      end
                                      if(i==4)
                                          CImgIndex = ImgIndex+3;
                                          if(CImgIndex<=LengthFiles-1)
                                              ComputeLowlevelSaliency(computeCol,mode,CImgIndex,para);
                                          end
                                      end
                                  end
                                   ImgIndex = ImgIndex + 4;
                                end
                                 toc
                                fprintf('done!\n');
                  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
 %}

                  fprintf('Step 5. Computation...\n');
                                    ImgIndex = 1;
                                    N = floor(LengthFiles*0.53);
                                    average_all = []; 
                                    for i=1:LengthFiles-1
                                         ImageName = Files(i).name;
                                          average = load([ para.AveragePath ImageName(1:end-4) 'average.mat']);
                                          average = average.average;
                                          average_all = [average_all; average];
                                    end
                                    average_new = sortrows(average_all,2);
                                    average = average_new(1:N,1)';
                                    

                                    
                  vote = length(find(average_new(:,2)<0.1200));%0.1200
                  vote1 = min(N,vote);
                  vote = vote1;
                  if(vote >= 10)
                      vote = vote / 2;
                      if(vote < 6)
                         vote = 6;
                      else    
                          if(LengthFiles < 110)
                              vote = 8;
                          else
                              vote = min(8 * floor(LengthFiles/110),vote);
                          end
                      end
                  end
%}                  
                  
                  
                  

                  numMatrixCell = {};
                  for i = 1:ceil(length(Files)/10)
                      numMatrixCell{i} = [];
                  end
                 
                  latindex = [];
                  voteNum = 0;
                  for i = 1:vote1
                     numMatrix = numMatrixCell{ ceil(average(i)/10) };
                     numMatrix = [numMatrix average(i)];
                     
                     
                     if( isempty(numMatrixCell{ceil(average(i)/10)}) && (voteNum < vote) )
                         latindex = [latindex average(i)];
                         voteNum = voteNum + 1;
                     end
                     numMatrixCell{ ceil(average(i)/10) } = numMatrix;
                  end
   
                      for i = 1:ceil(length(Files)/10)
                          if(~isempty(numMatrixCell{i}) && (length(latindex) < vote))
                          if(mod(numMatrixCell{i}(1)-1,10) >= 0 && mod(numMatrixCell{i}(1)-1,10) <=4)

                                 k = 2;
                                 while( k<= length(numMatrixCell{i}) && ~(mod(numMatrixCell{i}(k)-1,10) >= 5 && mod(numMatrixCell{i}(k)-1,10) <=9))
                                     k = k + 1;
                                 end
                                 if(k <= length(numMatrixCell{i}))
                                    latindex = [latindex numMatrixCell{i}(k)];
                                 elseif(length(numMatrixCell{i})>=2)
                                     latindex = [latindex numMatrixCell{i}(2)];
                                 end
                          else
  
                                 k = 2;
                                 while( k<= length(numMatrixCell{i}) && ~(mod(numMatrixCell{i}(k)-1,10) >= 0 && mod(numMatrixCell{i}(k)-1,10) <=4) )
                                     k = k + 1;
                                 end
                                 if(k <= length(numMatrixCell{i}))
                                    latindex = [latindex numMatrixCell{i}(k)];
                                 elseif(length(numMatrixCell{i})>=2)
                                     latindex = [latindex numMatrixCell{i}(2)];
                                 end
                          end
                          end
                      end

 
  if(persent > 0.0250)
                      latindex_temp = latindex;
                                    average_all1 = []; 
                                    for i=1:LengthFiles-1
                                         ImageName = Files(i).name;
                                          average1 = load([ para.AveragePath ImageName(1:end-4) 'average1.mat']);
                                          average1 = average1.average1;
                                          average_all1 = [average_all1; average1];
                                    end
                                    average_new1 = sortrows(average_all1,2);
                                    average1 = average_new1(:,1)';
                                    vote = length(find(average_new1(:,2)<0.6000));

                  numMatrixCell = {};
                  for i = 1:ceil(length(Files)/10)
                      numMatrixCell{i} = [];
                  end

                  latindex = [];
                  voteNum = 0;
                  for i = 1:vote
                     numMatrix = numMatrixCell{ ceil(average1(i)/10) };
                     numMatrix = [numMatrix average1(i)];

                     if( isempty(numMatrixCell{ceil(average1(i)/10)}) && (voteNum < vote) )
                         latindex = [latindex average1(i)];
                         voteNum = voteNum + 1;
                     end
                     numMatrixCell{ ceil(average1(i)/10) } = numMatrix;
                  end

                      for i = 1:ceil(length(Files)/10)
                          if(~isempty(numMatrixCell{i}) && (length(latindex) < vote))
                          if(mod(numMatrixCell{i}(1)-1,10) >= 0 && mod(numMatrixCell{i}(1)-1,10) <=4)

                                 k = 2;
                                 while( k<= length(numMatrixCell{i}) && ~(mod(numMatrixCell{i}(k)-1,10) >= 5 && mod(numMatrixCell{i}(k)-1,10) <=9))
                                     k = k + 1;
                                 end
                                 if(k <= length(numMatrixCell{i}))
                                    latindex = [latindex numMatrixCell{i}(k)];
                                 elseif(length(numMatrixCell{i})>=2)
                                     latindex = [latindex numMatrixCell{i}(2)];
                                 end
                          else
  
                                 k = 2;
                                 while( k<= length(numMatrixCell{i}) && ~(mod(numMatrixCell{i}(k)-1,10) >= 0 && mod(numMatrixCell{i}(k)-1,10) <=4) )
                                     k = k + 1;
                                 end
                                 if(k <= length(numMatrixCell{i}))
                                    latindex = [latindex numMatrixCell{i}(k)];
                                 elseif(length(numMatrixCell{i})>=2)
                                     latindex = [latindex numMatrixCell{i}(2)];
                                 end
                          end
                          end
                      end
                      
                  latindex = [latindex_temp latindex];
  end
                  if(isempty(latindex))
                      vote = 8;
                      latindex = average(1:vote);
                  end
                 
                      

                  
ImageName = Files(3).name;
ImagePath = [path ImageName];
I_orignal = imread(ImagePath);
imageHeight = size(I_orignal,1);imageWidth = size(I_orignal,2);




%%
ResultPath = ['.\sequence\proposal\' mode '\'];
mkdir(ResultPath);
iter = 1;



gtPath = ['.\train\' mode '\' num2str(iter) '\'];
para.gtPath = gtPath;
if(exist([gtPath 'trainName.txt'],'file'))
    delete([gtPath 'trainName.txt']);
end

%%
delete([gtPath '*.caffemodel']);


%%
for ImgIndex = latindex
        ImageName = Files(ImgIndex).name;    
   
        ImagePath = [path ImageName];
        I_orignal = imread(ImagePath);
       
        LowlevelSal = single(imread([para.LowlevelSaliencyPath ImageName(1:end-4) '.jpg']));
        LowlevelSal = LowlevelSal(:,:,1) ./ 255;
        LowlevelSal = imresize(LowlevelSal,[300 300]);
   
        prepare_groundtruth(LowlevelSal,ResultPath,I_orignal,para,imageHeight,imageWidth,ImgIndex,ImageName,gt_threshold);
end
    


F = dir([gtPath,'*.png']);
for k=1:length(F)
   ImageName = F(k).name;
   ImagePath = [gtPath ImageName];
   I = imread(ImagePath);
   I = imresize(I,[300 300]);
   imwrite(I,[gtPath ImageName]);
 
end

F=[];
F = dir([gtPath,'*.jpg']);
for k=1:length(F)
   ImageName = F(k).name;
   ImagePath = [gtPath ImageName];
   I = imread(ImagePath);
   I = imresize(I,[300 300]);
   imwrite(I,[gtPath ImageName]);
 
end    
%}
   

max_iter = length(latindex(:));
snapshot = max_iter;
% Rarely when object motion saliency has a tiny range in area size, it can be more accurate than saliency obtained
% by finetuned RADF model.
if(persent > 0.0250)
    
    tic
    
    caffe_train_RADF(max_iter,snapshot,mode,  num,gt_threshold,base1,base2,iter);

    toc

%% test RADF
tic

s=strcat('mkdir ',['.\sequence\Result-RADF\' mode '\']);system(s);
caffe.set_mode_gpu();       %����cpu����gpuģʽ
caffe.reset_all();

deploy = 'deploy.prototxt';      %����ģ�ͽṹ
F_model = dir(['./train/' mode '/' num2str(iter) '/snapshotRADF_*.caffemodel']);
caffe_model = ['./train/' mode '/' num2str(iter) '/' F_model.name];     %ѵ���õ�ģ��

net = caffe.Net(deploy, caffe_model, 'test');     %�����������ֱ���������Խṹ��ѵ���õĲ���ģ�ͣ�test



for k=1:LengthFiles-1

    EPSILON = 1e-28;
        
    ImageName = Files(k).name;
    
    
    ImagePath = [path ImageName];
    I_orignal = imread(ImagePath);

    I_orignal = imresize(I_orignal,[400,400]);
    I_orignal = single(I_orignal);
       
    
        I_orignal(:,:,1) = I_orignal(:,:,1) - single(104);
        I_orignal(:,:,2) = I_orignal(:,:,2) - single(117);
        I_orignal(:,:,3) = I_orignal(:,:,3) - single(123);
        



         % convert image to BGR and single
         I_orignal = I_orignal(:,:,[3 2 1]);
         I_orignal = permute(I_orignal, [2, 1, 3]); % ת����width��height����
         
        
         net.blobs('data').reshape([400 400 3 1]); % reshape blob 'data'
         net.reshape();
         %input_data must be a cell array
         net.forward({I_orignal});

         
         
         out1 = net.blobs('sigmoid-dsn1').get_data();
         %out1=out1(end:-1:1,:);%����      
         %out1=imrotate(out1,-90);%��ת
         out1 = (out1 - min(out1(:)) + EPSILON) / (max(out1(:)) - min(out1(:)) + EPSILON);
         
         out2 = net.blobs('sigmoid-dsn2').get_data();
         %out2=out2(end:-1:1,:);%����      
         %out2=imrotate(out2,-90);%��ת
         out2 = (out2 - min(out2(:)) + EPSILON) / (max(out2(:)) - min(out2(:)) + EPSILON);
         
         out3 = net.blobs('sigmoid-dsn3').get_data();
         %out3=out3(end:-1:1,:);%����      
         %out3=imrotate(out3,-90);%��ת
         out3 = (out3 - min(out3(:)) + EPSILON) / (max(out3(:)) - min(out3(:)) + EPSILON);
         
         out4 = net.blobs('sigmoid-dsn4').get_data();
         %out4=out4(end:-1:1,:);%����      
         %out4=imrotate(out4,-90);%��ת
         out4 = (out4 - min(out4(:)) + EPSILON) / (max(out4(:)) - min(out4(:)) + EPSILON);
         
         out5 = net.blobs('sigmoid-dsn5').get_data();
         %out5=out5(end:-1:1,:);%����      
         %out5=imrotate(out5,-90);%��ת
         out5 = (out5 - min(out5(:)) + EPSILON) / (max(out5(:)) - min(out5(:)) + EPSILON);
         
         out6 = net.blobs('sigmoid-dsn6').get_data();
         %out6=out6(end:-1:1,:);%����      
         %out6=imrotate(out6,-90);%��ת
         out6 = (out6 - min(out6(:)) + EPSILON) / (max(out6(:)) - min(out6(:)) + EPSILON);
         
         fuse = net.blobs('sigmoid-fuse').get_data();
         %fuse=fuse(end:-1:1,:);%����      
         %fuse=imrotate(fuse,-90);%��ת
         fuse = (fuse - min(fuse(:)) + EPSILON) / (max(fuse(:)) - min(fuse(:)) + EPSILON);
         
         
         
         out2a = net.blobs('sigmoid-dsn2a').get_data();
         %out2a=out2a(end:-1:1,:);%����      
         %out2a=imrotate(out2a,-90);%��ת
         out2a = (out2a - min(out2a(:)) + EPSILON) / (max(out2a(:)) - min(out2a(:)) + EPSILON);
         
         
         out3a = net.blobs('sigmoid-dsn3a').get_data();
         %out3a=out3a(end:-1:1,:);%����      
         %out3a=imrotate(out3a,-90);%��ת
         out3a = (out3a - min(out3a(:)) + EPSILON) / (max(out3a(:)) - min(out3a(:)) + EPSILON);
         
         out4a = net.blobs('sigmoid-dsn4a').get_data();
         %out4a=out4a(end:-1:1,:);%����      
         %out4a=imrotate(out4a,-90);%��ת
         out4a = (out4a - min(out4a(:)) + EPSILON) / (max(out4a(:)) - min(out4a(:)) + EPSILON);
         
         out5a = net.blobs('sigmoid-dsn5a').get_data();
         %out5a=out5a(end:-1:1,:);%����      
         %out5a=imrotate(out5a,-90);%��ת
         out5a = (out5a - min(out5a(:)) + EPSILON) / (max(out5a(:)) - min(out5a(:)) + EPSILON);
         
         out6a = net.blobs('sigmoid-dsn6a').get_data();
         %out6a=out6a(end:-1:1,:);%����      
         %out6a=imrotate(out6a,-90);%��ת
         out6a = (out6a - min(out6a(:)) + EPSILON) / (max(out6a(:)) - min(out6a(:)) + EPSILON);
         
         out1a = net.blobs('sigmoid-dsn1a').get_data();
         %out1a=out1a(end:-1:1,:);%����      
         %out1a=imrotate(out1a,-90);%��ת
         out1a = (out1a - min(out1a(:)) + EPSILON) / (max(out1a(:)) - min(out1a(:)) + EPSILON);
         
         
         

         res = (out1 + out2 + out6 + out3 + out4 + out5 + fuse + out2a + out1a + out3a + out4a + out5a + out6a) / 13;
         res = res(end:-1:1,:);%����      
         res = imrotate(res,-90);%��ת

        
        
        res = (res - min(res(:)) + EPSILON) / (max(res(:)) - min(res(:)) + EPSILON);
        res = imresize(res,[imageHeight imageWidth]);       
        
        imwrite(res,['.\sequence\Result-RADF\' mode '\' ImageName(1:end-4) '.jpg']);              
end
%}


caffe.reset_all(); 

%%
    exponent = 0.4;
    SourcePath =  ['.\sequence\Result-RADF\' mode '\'];
    SourcePath1 =  ['.\sequence\Result-RADF-lowlevel' num2str(exponent) '\' mode '\'];
    s=strcat('mkdir ',SourcePath1);system(s);
    F=[];
    F = dir([SourcePath,'*.jpg']);
    for k=1:length(F)
       ImageName = F(k).name;
       ImagePath = [SourcePath ImageName];
       I = single(imread(ImagePath));
       I = I(:,:,1) ./ 255;

       I_train_gt = single(imread([para.LowlevelSaliencyPath ImageName(1:end-4) '.jpg'])); 
       I_train_gt = I_train_gt(:,:,1) ./ 255;
       
       I_train_gt = I_train_gt .^ exponent;

       average1 = load([ para.AveragePath ImageName(1:end-4) 'average1.mat']);
       average1 = average1.average1(1,2);
       if(average1 > 0.8000 && persent > 0.1200)
           L = I;
       else
           L = I .*  I_train_gt;
       end
       L = normalizeMatrix(L);
       imwrite(L,[SourcePath1 ImageName]);

    end
    toc
end
     

tic
%%
finalPath = ['.\sequence\FinalPixelResult\' mode '\'];
s=strcat('mkdir ',['.\sequence\FinalPixelResult\' mode '\']);system(s);
for k=1:LengthFiles-1
    ImageName = Files(k).name;
    
    if(persent > 0.0250)               
        ImagePath = ['.\sequence\Result-RADF-lowlevel' num2str(exponent) '\' mode '\' ImageName(1:end-4) '.jpg'];
        I = imread(ImagePath);               
        I = im2double(I);
        imwrite(I,[finalPath ImageName(1:end-4) '.jpg']);
    else
                                
        ImagePath = ['.\sequence\LowlevelSaliency\' mode '\' ImageName(1:end-4) '.jpg'];
        I = imread(ImagePath);               
        I = im2double(I);
        I = imresize(I,[300,300]);
        
        ImagePath = [path ImageName];
        I1 = imread(ImagePath);
        I1 = im2double(I1);
        I1 = imresize(I1,[300,300]);
        I3 = pixelAssign(I,I1,15,80);
        I3 = imresize(I3,[imageHeight imageWidth]); 
        imwrite(I3,[finalPath ImageName(1:end-4) '.jpg']);
    end
end
toc;
%}