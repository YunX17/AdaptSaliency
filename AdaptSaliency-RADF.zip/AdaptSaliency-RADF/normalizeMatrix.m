function [I] = normalizeMatrix(I)

maxValue = max(max(I));
minValue = min(min(I));

% meanValue = mean(mean(I));

if(maxValue-minValue~=0)
I = (I-minValue)/(maxValue-minValue);
end

% if(maxValue-meanValue~=0)
% I = (I-meanValue)/(maxValue-minValue);
% end

