function [ output_args ] = prepare_groundtruth( LowlevelSal,... 
    SelectiveSearchResultPath,I_orignal,para,imageHeight,imageWidth,ImgIndex,ImageName,gt_threshold )
%FINDPROPOSALDEPENDONSHAPEPRIOR �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

 
       threshold = 0.18;
      
           minX = 300;
           maxX = 1;
           minY = 300;
           maxY = 1;
           minXMatrix = [];
           minYMatrix = [];
           for i=1:300
               for ii=1:300

                   if(LowlevelSal(i,ii) > threshold)
                       minXMatrix = [minXMatrix i];
                       minYMatrix = [minYMatrix ii];

                       if( i < minX )
                           minX = i;
                       end
                       if( i > maxX)
                           maxX = i;
                       end
                       if( ii < minY )
                           minY = ii;
                       end
                       if( ii > maxY )
                           maxY = ii;
                       end
                   end
               end
           end


       scaleH = imageHeight / 300;
       scaleW = imageWidth / 300;
       
       
       interval = 40;
       minXtemp = [];
       minYtemp = [];
       maxXtemp = [];
       maxYtemp = [];
       %%%
       minXMatrix = sort(minXMatrix);
       minX = minXMatrix(ceil(end*0.001));
       minYMatrix = sort(minYMatrix);
       minY = minYMatrix(ceil(end*0.001));
       
       % prevent saliency discrete distribution
       temp = [];
       temp = minXMatrix(2:end) - minXMatrix(1:end-1);
       index = find(temp(:)>interval);     
       if(~isempty(index))
           minXtemp = [minXtemp minXMatrix(ceil(end*0.001))];
           minXtemp = [minXtemp minXMatrix(index+1)];
       else
           minXtemp = minX;
       end

       
       %%%
       maxX = minXMatrix(ceil(end*0.999));
       % prevent saliency discrete distribution
       temp = [];
       temp = minXMatrix(2:end) - minXMatrix(1:end-1);
       index = find(temp(:)>interval);     
       if(~isempty(index))
           maxXtemp = [maxXtemp minXMatrix(index)];
           maxXtemp = [maxXtemp minXMatrix(ceil(end*0.999))];
       else
           maxXtemp = maxX;
       end
       
       
       % prevent saliency discrete distribution
       temp = [];
       temp = minYMatrix(2:end) - minYMatrix(1:end-1);
       index = find(temp(:)>interval);     
       if(~isempty(index))
           minYtemp = [minYtemp minYMatrix(ceil(end*0.001))];
           minYtemp = [minYtemp minYMatrix(index+1)];
       else
           minYtemp = minY;
       end

       
       %%%
       maxY = minYMatrix(ceil(end*0.999));
       % prevent saliency discrete distribution
       temp = [];
       temp = minYMatrix(2:end) - minYMatrix(1:end-1);
       index = find(temp(:)> interval);     
       if(~isempty(index))
           maxYtemp = [maxYtemp minYMatrix(index)];
           maxYtemp = [maxYtemp minYMatrix(ceil(end*0.999))];
       else
           maxYtemp = maxY;
       end
       
       %region minXtemp maxXtemp ���ȿ϶�һ�� Yͬ��
       maxPixelNumber = 0;
       for i = 1:length(minXtemp)
               for j = 1:length(minYtemp)
                   %region = [region ; minXtemp(i) minYtemp(j) maxXtemp(i) maxYtemp(j)];
%                    int32(minXtemp(i))
%                    int32(maxXtemp(i))
%                    int32(minYtemp(j))
%                    int32(maxYtemp(j))
%                    i
%                    j
                   region_greather_than_threshold = numel(find(LowlevelSal(int32(minXtemp(i)):int32(maxXtemp(i)), ...
                                                           int32(minYtemp(j)):int32(maxYtemp(j)) )>threshold*1.5 ));
                   if(region_greather_than_threshold > maxPixelNumber)
                       maxPixelNumber = region_greather_than_threshold;
                       minX = minXtemp(i);
                       maxX = maxXtemp(i);
                       minY = minYtemp(j);
                       maxY = maxYtemp(j);
                   end  
               end
       end

       
       minX = minX * scaleH;
       minX = int32(ceil(minX));
       
       maxX = maxX * scaleH;
       maxX = int32(ceil(maxX));
       
       minY = minY * scaleW;
       minY = int32(ceil(minY));
       
       maxY = maxY * scaleW;
       maxY = int32(ceil(maxY));       



   
   proposalResult = [];
   
   
   
   
   if(  ((( double(maxX)-double(minX) ) / ( double(maxY)-double(minY) ))  < 8) && ...
           ((( double(maxX)-double(minX) ) / ( double(maxY)-double(minY) ))  > 0.125 )  )%8 0.125
       proposalResult = [proposalResult ; [minX minY maxX maxY] ];
           I_train_gt = single(imread([para.LowlevelSaliencyPath ImageName(1:end-4) '.jpg'])); 
           I_train_gt = I_train_gt(:,:,1) ./ 255;
           I_train_gt(find(I_train_gt(:)<= gt_threshold)) = 0;
           I_train_gt = I_train_gt .^ 0.3;
           I_train_gt = imresize(I_train_gt,[400 400]);
            

%% save GT results
           gtPath = para.gtPath;
           mkdir(gtPath);
           
           original_path = para.path;
           %���ԭͼ��png,����bmp,ת����jpg��ʽ
           I_original = imread([original_path ImageName]);
           imwrite(I_original,[gtPath ImageName(1:end-4) '.jpg']);

           gtName = [gtPath ImageName(1:end-4) '.png'];
           imwrite(I_train_gt,gtName);


            id = fopen([gtPath 'trainName.txt'],'a');
                fprintf(id,[ImageName(1:end-4) '.jpg ' ImageName(1:end-4) '.png' '\r\n']);
            fclose(id);
              

       
      %% draw proposals on current original frame, 
       %the 3-rd parameter means the number of current frame, i.e., all the proposals are separated to draw on identical frames. 
       %drawRectangleOnDifferentImage(I_orignal ,proposalResult,1 , SelectiveSearchResultPath , ImgIndex,ImageName);
      
       %save([SelectiveSearchResultPath ImageName(1:end-4) 'final.mat'],'proposalResult')
   end

end