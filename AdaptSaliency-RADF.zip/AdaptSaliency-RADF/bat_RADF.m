
%%
num=10;
th=0.1;


main_RADF('bear',num,th,1,9)
main_RADF('dance-twirl',num,th,1,9)
main_RADF('mallard-fly',num,th,1,9)
main_RADF('SegTrack\worm',num,th,1,9)%